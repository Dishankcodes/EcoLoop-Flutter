import 'dart:convert';

import 'package:dio/dio.dart';

import '../api/api_manager.dart';
import '../shared_preferences_util.dart';

class EcoLoopApiException implements Exception {
  final String message;

  const EcoLoopApiException(this.message);

  @override
  String toString() => message;
}

/// Thin typed-enough wrapper around the routes implemented in Code.gs.
/// All writes go through the same Dio instance as the existing Retrofit client,
/// so the Apps Script redirect interceptor is reused.
class _CachedGet {
  const _CachedGet(this.value, this.expiresAt);

  final dynamic value;
  final DateTime expiresAt;
}

class EcoLoopApi {
  static const String baseUrl =
      'https://script.google.com/macros/s/AKfycbzvHq06GwL_I8qH2IPyQP36dRlESN62PYF4Ak5WkRE2VjHL5a-tr0Yk_KEtSvU_ZL6IbQ/exec';

  EcoLoopApi._();

  static final EcoLoopApi instance = EcoLoopApi._();

  // Short-lived in-memory cache for safe, read-only reference/discovery data.
  // Transactional and account-specific endpoints are intentionally not cached.
  static const Duration _categoriesTtl = Duration(minutes: 10);
  static const Duration _locationsTtl = Duration(hours: 6);
  static const Duration _publicDiscoveryTtl = Duration(seconds: 15);

  final Map<String, _CachedGet> _getCache = <String, _CachedGet>{};
  final Map<String, Future<dynamic>> _inFlightGets =
      <String, Future<dynamic>>{};

  int _cacheGeneration = 0;

  /// Clear cached GET data after a successful write or when the caller knows
  /// that server-side data changed. This is deliberately broad and safe.
  void invalidateCache() {
    _cacheGeneration++;
    _getCache.clear();

    // Existing requests cannot be cancelled, but new callers must not join a
    // request that started before the write/invalidation.
    _inFlightGets.clear();
  }

  String get _token =>
      (Prefs.getString('userRole').toLowerCase() == 'artist'
              ? Prefs.getString('artistToken')
              : Prefs.getString('authToken'))
          .trim();

  Future<dynamic> get(
    String path, {
    Map<String, dynamic> query = const {},
  }) async {
    final ttl = _cacheTtlFor(path, query);

    // Non-whitelisted endpoints are always fetched fresh.
    if (ttl == null) {
      return _send('GET', path, query: query);
    }

    final key = _cacheKey(path, query);
    final now = DateTime.now();

    final cached = _getCache[key];

    if (cached != null && cached.expiresAt.isAfter(now)) {
      return _copyJsonValue(cached.value);
    }

    if (cached != null) {
      _getCache.remove(key);
    }

    // Share an identical request already in progress.
    final existing = _inFlightGets[key];
    if (existing != null) {
      return _copyFutureValue(existing);
    }

    final generationAtStart = _cacheGeneration;

    late final Future<dynamic> request;

    request = _send('GET', path, query: query)
        .then((value) {
          // Do not store a response if a write invalidated the cache while this
          // request was running; that response could represent pre-write data.
          if (generationAtStart == _cacheGeneration) {
            _getCache[key] = _CachedGet(
              _copyJsonValue(value),
              DateTime.now().add(ttl),
            );
          }

          return value;
        })
        .whenComplete(() {
          if (identical(_inFlightGets[key], request)) {
            _inFlightGets.remove(key);
          }
        });

    _inFlightGets[key] = request;

    return _copyFutureValue(request);
  }

  Future<dynamic> post(String path, Map<String, dynamic> body) async {
    final result = await _send('POST', path, body: body);
    invalidateCache();
    return result;
  }

  Future<dynamic> put(String path, Map<String, dynamic> body) async {
    final result = await _send('PUT', path, body: body);
    invalidateCache();
    return result;
  }

  Future<dynamic> delete(String path) async {
    final result = await _send('DELETE', path);
    invalidateCache();
    return result;
  }

  Duration? _cacheTtlFor(String path, Map<String, dynamic> query) {
    final normalized = path.split('?').first.trim();

    if (normalized == '/categories' || normalized == '/locations/states') {
      return normalized == '/categories' ? _categoriesTtl : _locationsTtl;
    }

    if (normalized == '/locations/cities' &&
        (query['stateCode']?.toString().trim().isNotEmpty ?? false)) {
      return _locationsTtl;
    }

    // Public marketplace discovery can be briefly stale while browsing, but
    // checkout always revalidates the product and available stock server-side.
    if (normalized == '/products') {
      return _publicDiscoveryTtl;
    }

    return null;
  }

  String _cacheKey(String path, Map<String, dynamic> query) {
    final sortedQuery = query.keys.toList()..sort();

    final queryString = sortedQuery
        .map((key) => '$key=${query[key]}')
        .join('&');

    // Only explicitly whitelisted public/reference GETs are cached, so tokens
    // are not included in keys or written to persistent storage.
    return '$path?$queryString';
  }

  dynamic _copyJsonValue(dynamic value) {
    if (value == null || value is String || value is num || value is bool) {
      return value;
    }

    try {
      return jsonDecode(jsonEncode(value));
    } catch (_) {
      return value;
    }
  }

  Future<dynamic> _copyFutureValue(Future<dynamic> future) async {
    return _copyJsonValue(await future);
  }

  Future<dynamic> _send(
    String method,
    String path, {
    Map<String, dynamic> body = const {},
    Map<String, dynamic> query = const {},
  }) async {
    final payload = <String, dynamic>{...body};

    if (method != 'GET') {
      if (_token.isNotEmpty) {
        payload['token'] = _token;
      }

      payload['_method'] = method;
    }

    final response = await ApiManager().dio.request<dynamic>(
      baseUrl,
      queryParameters: {
        'path': path,
        ...query,
        if ((method == 'GET' || method == 'DELETE') && _token.isNotEmpty)
          'token': _token,

        // Apps Script receives DELETE via doPost; pass method override in query
        // because DELETE requests intentionally have no request body here.
        if (method == 'DELETE') '_method': 'DELETE',
      },
      data: method == 'GET' || method == 'DELETE' ? null : payload,
      options: Options(method: method == 'GET' ? 'GET' : 'POST'),
    );

    dynamic raw = response.data;

    if (raw is String) {
      try {
        raw = jsonDecode(raw);
      } catch (_) {}
    }

    if (raw is! Map) {
      throw const EcoLoopApiException(
        'The backend did not return JSON. Check the Apps Script deployment URL and access permissions.',
      );
    }

    final ok =
        raw['success'] == true ||
        raw['success'].toString().toLowerCase() == 'true';

    if (!ok) {
      final err = raw['error'];
      final message = err is Map ? err['message']?.toString() : err?.toString();

      throw EcoLoopApiException(
        (message == null || message.isEmpty) ? 'Request failed.' : message,
      );
    }

    return raw['data'];
  }

  static int categoryId(String? label) {
    final value = (label ?? '').trim().toLowerCase();

    if (value.contains('furniture')) return 1;
    if (value.contains('decor') || value.contains('home')) return 2;
    if (value.contains('wood')) return 3;
    if (value.contains('glass')) return 4;

    if (value.contains('paper') ||
        value.contains('craft') ||
        value.contains('book')) {
      return 5;
    }

    if (value.contains('fashion') || value.contains('cloth')) {
      return 6;
    }

    if (value.contains('plant') || value.contains('garden')) {
      return 7;
    }

    return 8;
  }
}
