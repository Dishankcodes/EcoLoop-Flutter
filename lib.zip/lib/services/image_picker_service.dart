import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

class PickedImageData {
  final Uint8List bytes;
  final String base64;
  final String fileName;
  final String mimeType;

  const PickedImageData({
    required this.bytes,
    required this.base64,
    required this.fileName,
    required this.mimeType,
  });
}

class ImagePickerService {
  ImagePickerService._();

  static final ImagePicker _picker = ImagePicker();

  static Future<PickedImageData?> pickImage({
    required ImageSource source,
    int imageQuality = 80,
    double maxWidth = 1600,
    double maxHeight = 1600,
    int maxBytes = 5 * 1024 * 1024,
  }) async {
    try {
      final XFile? image = await _picker.pickImage(
        source: source,
        imageQuality: imageQuality,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        preferredCameraDevice: CameraDevice.front,
      );

      if (image == null) {
        return null;
      }

      final Uint8List bytes = await image.readAsBytes();

      if (bytes.isEmpty) {
        throw const ImagePickerException(
          'The selected image is empty or could not be read.',
        );
      }

      if (bytes.length > maxBytes) {
        final maxMb = maxBytes / (1024 * 1024);

        throw ImagePickerException(
          'Please choose a smaller image. Maximum size is ${maxMb.toStringAsFixed(0)} MB.',
        );
      }

      final String extension = _getExtension(image.name);

      final String fileName = _buildFileName(extension);

      final String mimeType = _getMimeType(extension);

      final String base64 = base64Encode(bytes);

      return PickedImageData(
        bytes: bytes,
        base64: base64,
        fileName: fileName,
        mimeType: mimeType,
      );
    } on ImagePickerException {
      rethrow;
    } catch (e) {
      debugPrint('Image picker error: $e');

      throw const ImagePickerException(
        'Unable to select the image. Please try again.',
      );
    }
  }

  static String _getExtension(String fileName) {
    final int dotIndex = fileName.lastIndexOf('.');

    if (dotIndex == -1 || dotIndex == fileName.length - 1) {
      return 'jpg';
    }

    final extension = fileName.substring(dotIndex + 1).toLowerCase();

    switch (extension) {
      case 'jpg':
      case 'jpeg':
        return 'jpg';

      case 'png':
        return 'png';

      case 'webp':
        return 'webp';

      case 'heic':
      case 'heif':
        return 'jpg';

      default:
        return 'jpg';
    }
  }

  static String _getMimeType(String extension) {
    switch (extension) {
      case 'png':
        return 'image/png';

      case 'webp':
        return 'image/webp';

      case 'jpg':
      case 'jpeg':
      default:
        return 'image/jpeg';
    }
  }

  static String _buildFileName(String extension) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;

    return 'profile_$timestamp.$extension';
  }
}

class ImagePickerException implements Exception {
  final String message;

  const ImagePickerException(this.message);

  @override
  String toString() => message;
}
